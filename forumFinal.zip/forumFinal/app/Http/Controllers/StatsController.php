<?php

namespace App\Http\Controllers;

use App\Models\Stats;
use Illuminate\Http\Request;

class StatsController extends Controller
{


    public function update(Stats $stats) {
        $validated = request()->validate([
            'bmi' => 'numeric',
            'squat' => 'numeric',
            'bench_press' => 'numeric',
            'dead_lift' => 'numeric',
        ]);


        $this->show();
    }
}
