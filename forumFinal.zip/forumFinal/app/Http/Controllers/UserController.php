<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;

class UserController extends Controller
{
    public function show(User $user) {
        $posts = $user->posts()->paginate(5);
        return view('profile-page',compact('user','posts'));
    }

    public function edit(User $user) {
        return view('shared.edit-profile-page',compact('user'));
    }

    public function update(User $user) {
        $validated = request()->validate([
            'name' => 'required|min:5|max:30',
            'bio' => 'nullable|min:1|max:255',
            'image' => 'nullable|mimes:jpeg,png,jpg,gif,svg|max:2048',
            'bmi' => 'numeric',
            'squat' => 'numeric',
            'bench_press' => 'numeric',
            'dead_lift' => 'numeric',
        ]);

        if (request()->has('image')) {
            $imagePath = request()->file('image')->store('profile_picture', 'public');
            $validated['image'] = $imagePath;
        }

        $user->update($validated);
        $user->stats->update($validated);

        return $this->show($user);
    }

    public function destroy(User $user) {
        $user->delete();
        return redirect()->route('forum')->with('success', 'Account deleted successfully!');
    }
}
