<?php

namespace App\Http\Controllers;

use App\Models\Post;
use Carbon\Carbon;
use Illuminate\Http\Request;


class PostController extends Controller
{
    public function store() {
        $validated = request()->validate([
            'content' => 'required|min:5|max:240'
        ]);

        $validated['user_id'] = auth()->id();

        Post::create($validated);

        return redirect()->route('forum')->with('success', 'Post created successfully!');
    }

    public function show(Post $post) {
        return view('posts.showPost', compact('post'));
    }

    public function edit(Post $post) {
        $editing = true;

        return view('posts.showPost', compact('post', 'editing'));
    }

    public function update(Post $post) {
        request()->validate([
            'content' => 'required|min:5|max:240'
        ]);

        $post->content = request()->get('content', '');
        $post->save();

        return redirect()->route('post.show', $post->id)->with('success', 'Post updated successfully!');
    }

    public function destroy(Post $post) {
        $post->delete();
        return redirect()->route('forum')->with('success', 'Post deleted successfully!');
    }

    public function getCreationTime($postId)
    {
        $post = Post::find($postId);

        if (!$post) {
            return response()->json(['error' => 'Post not found'], 404);
        }

        $secondsAgo = Carbon::parse($post->created_at)->diffInSeconds(now());

        return response()->json(['secondsAgo' => $secondsAgo]);
    }
}


