<?php

namespace App\Http\Controllers;

use App\Models\Post;
use Illuminate\Http\Request;

class ForumController extends Controller
{
public function index() {
    $query = request('search');

    $posts = Post::orderBy('created_at', 'DESC');

    if ($query) {
        $posts->where(function ($postQuery) use ($query) {
            $postQuery->where('content', 'like', '%' . $query . '%');


            if (request('search_users')) {
                $postQuery->orWhereHas('user', function ($userQuery) use ($query) {
                    $userQuery->where('name', 'like', '%' . $query . '%');
                });
            }
        });
    }

    return view('forum', [
        'posts' => $posts->paginate(5),
    ]);
}


}
