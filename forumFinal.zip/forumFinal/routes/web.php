<?php

use App\Http\Controllers\AuthController;
use App\Http\Controllers\CommentController;
use App\Http\Controllers\ForumController;
use App\Http\Controllers\PostController;
use App\Http\Controllers\UserController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/forum', [ForumController::class, 'index'])->name('forum');
Route::get('/forum/live-search', [ForumController::class, 'liveSearch'])->name('forum.live-search');




Route::post('/post', [PostController::class, 'store'])->name('post.store')->middleware('auth');

Route::get('/post/{post}', [PostController::class, 'show'])->name('post.show');

Route::get('/post/{post}/edit', [PostController::class, 'edit'])->name('post.edit')->middleware('auth');

Route::match(['put', 'post'], '/post/{post}', [PostController::class, 'update'])->name('post.update')->middleware('auth');

Route::delete('/post/{post}', [PostController::class, 'destroy'])->name('post.destroy')->middleware('auth');

Route::post('/post/{post}/like', [PostController::class, 'like'])->name('post.like');

Route::post('/post/{post}/unlike', [PostController::class, 'unlike'])->name('post.unlike');

Route::match(['get', 'post'], '/post/{post}/toggle-like', [PostController::class, 'toggleLike'])->name('post.toggleLike');

Route::get('/post/creation-time/{postId}', [PostController::class, 'getCreationTime'])->name('post.creation-time');


Route::resource('users', UserController::class)->only('show','edit','update')->middleware('auth');
Route::delete('/users/{user}', [UserController::class, 'destroy'])->name('users.destroy');



Route::post('/post/{post}/comments', [CommentController::class, 'store'])->name('post.comments.store')->middleware('auth');
Route::delete('/post/{post}/comments/{comment}', [CommentController::class, 'destroy'])->name('post.comments.delete')->middleware('auth');



Route::get('/register', [AuthController::class, 'register'])->name('register');

Route::post('/register', [AuthController::class, 'store']);

Route::get('/login', [AuthController::class, 'login'])->name('login');

Route::post('/login', [AuthController::class, 'authenticate']);

Route::get('/logout', [AuthController::class, 'logout'])->name('logout');



Route::get('/calculator1RM', function () {return view('calculator1RM'); });
Route::get('/calculatorBMI', function () {return view('calculatorBMI'); });
Route::get('/', function () {return view('home'); });



