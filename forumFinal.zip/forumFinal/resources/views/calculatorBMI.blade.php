@include('layout.nav-bar')



    <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BMI Calculator</title>
</head>
<body class="calculator-page-container">
<div style="background: url('{{ asset('images/calculator-background.jpg') }}') no-repeat center center fixed; background-size: cover; height: 100vh; margin: 0; padding: 0; position: relative;">

    <h1 style="text-align: center; color: #333;"><strong>BMI Calculator</strong></h1>

<div class="px-2 pt-4 pb-2 container mt-4">
    <div class="row">
        <div class="col-sm-6">
            <form id="bmiCalculatorForm" class="calculator-form">
                <strong for="metrics">Choose Metrics:</strong>
                <select id="metrics" name="metrics">
                    <option value="metric">Metric (kg/cm)</option>
                    <option value="imperial">Imperial (lbs/inches)</option>
                </select>
                <br>
                <br>

                <div class="form-group">
                    <strong for="weight" class="control-label">Enter Weight:</strong>
                    <div class="input-group">
                        <input type="number" id="weight" name="weight" required>
                    </div>
                </div>

                <div class="form-group">
                    <strong for="height" class="control-label">Enter Height:</strong>
                    <div class="input-group">
                        <input type="number" id="height" name="height" required>
                    </div>
                </div>

                <button type="button" onclick="calculateBMI()" class="calculator-button">Calculate BMI</button>

                <label for="bmiResult" class="calculator-result">BMI:</label>
                <span id="bmiResult"></span>

                <br>
                <br>
                @auth()
                    <a href="{{ route('users.edit', auth()->user()->id) }}" class="calculator-button">
                        Update your BMI here
                    </a>
                @endauth
            </form>
        </div>


        <div class="col-sm-6">
            @include('shared.weight-conversion')
            @include('shared.length-conversion')
        </div>

    </div>
    <img src="{{ asset('images/BMI.jpg') }}">
</div>
</div>

<script src="{{ asset('js/calculator.js') }}"></script>
</body>
</html>


