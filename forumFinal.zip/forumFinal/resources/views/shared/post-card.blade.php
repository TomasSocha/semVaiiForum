<div class="post-frame">
    <div class="custom-card">
        <div class="custom-header px-3 pt-4 pb-2">
            <div class="d-flex align-items-center justify-content-between">
                <div class="d-flex align-items-center">
                    <img style="width: 45px; height: 45px" class="me-2 avatar-sm rounded-circle" src="{{ $post->user->getImage() }}">
                    <div>
                        <h5 class="custom-title mb-0">
                            <a class="user-link" href="{{ route('users.show', $post->user->id) }}">{{ $post->user->name }}</a>
                        </h5>
                    </div>
                </div>

                <div>
                    <form method="POST" action="{{ route('post.destroy', $post->id) }}">
                        @csrf
                        @method('delete')
                        <a href="{{ route('post.show', $post->id) }}" class="crud-button">
                            <img src="{{ asset('images/view-icon.png') }}" class="view-icon">
                        </a>
                        @auth()
                            @if(auth()->user()->id === $post->user_id)
                                <a href="{{ route('post.edit', $post->id) }}" class="ms-1 crud-button">
                                    <img src="{{ asset('images/edit-icon.png') }}" class="edit-icon">
                                </a>
                                <form action="{{ route('post.destroy', $post->id) }}" method="POST" class="ms-1">
                                    @csrf
                                    @method('DELETE')
                                    <button type="submit" class="btn btn-danger btn-sm">Delete</button>
                                </form>
                            @endif
                        @endauth
                    </form>
                </div>
            </div>
        </div>

        <div class="custom-body card-body">
            @if($editing ?? false)
                <form action="{{ route('post.update', $post->id) }}" method="post">
                    @csrf
                    @method('PUT')
                    <div class="mb-3">
                        <textarea name="content" class="form-control" id="content" rows="3">{{ $post->content }}</textarea>
                        @error('content')
                        <span class="fs-6 text-danger">{{ $message }}</span>
                        @enderror
                    </div>
                    <div class="">
                        <button type="submit" class="btn btn-dark">Share</button>
                    </div>
                </form>
            @else
                <p class="fs-6 fw-light text-muted">{{ $post->content }}</p>
            @endif

                <div class="d-flex justify-content-between">
                    <div>
        <span class="fs-6 fw-light text-muted creation-time" data-post-id="{{ $post->id }}">
            <span class="fas fa-clock"></span>
            {{ $post->created_at }}
        </span>
                    </div>
                </div>


                <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
                <script src="{{ asset('js/time-updater.js') }}"></script>


                @include('shared.comments-card')
        </div>
    </div>
</div>
