<div>
    <form  id="commentForm"  action="{{route('post.comments.store',$post->id)}}" method="POST">
        @csrf
    <div class="mb-3">
        <textarea id="content" name="content" class="fs-6 form-control" rows="1"></textarea>
    </div>
    <div>
        <button type="submit" class="btn btn-dark btn-sm"> Post Comment </button>
    </div>
    </form>
    <hr>

    @foreach($post->comments as $comment)
        <div class="d-flex align-items-start comment-container">
            @if(Auth::id() === $comment->user->id)
                <form method="POST" action="{{ route('post.comments.delete', ['post' => $post->id, 'comment' => $comment->id]) }}">
                    @csrf
                    @method('DELETE')
                    <button type="submit" class="btn btn-sm">Delete</button>
                </form>
            @endif

            <img style="width: 35px; height: 35px" class="me-2 avatar-sm rounded-circle"
                 src="{{$comment->user->getImage()}}">
            <div class="w-100">
                <div class="d-flex justify-content-between">
                    <h6 class=""><a class="user-link" href="{{route('users.show',$comment->user->id)}}">{{$comment->user->name}}</a></h6>



                    <small class="fs-6 fw-light text-muted">{{$comment->created_at}}</small>

                </div>

                <p class="fs-6 fw-light">
                    {{$comment->content}}
                </p>

            </div>
        </div>
    @endforeach
    <script src="{{ asset('js/comment.js') }}"></script>
</div>
