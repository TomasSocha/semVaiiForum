@include('layout.nav-bar')

    <!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Profile</title>
</head>

<body class="profile-page">

<div class="profile-container">
    <img src={{$user->getImage()}} class="profile-image">
    <form enctype="multipart/form-data" method="POST" action="{{ route('users.update', $user->id) }}">
        @csrf
        @method('PUT')

        <div class="profile-info">

            <button type="submit" class="ms-1 crud-button">
                <img src="{{ asset('images/save-icon.png') }}" class="edit-profile-icon" alt="Save">
            </button>
            <h5>Name:</h5>
            <input name="name" value="{{ $user->name }}" type="text" class="form-control">
            @error('name')
            <span class="text-danger fs-6">{{ $message }}</span>
            @enderror

            <h5>Profile picture:</h5>
            <input name="image" type="file" class="form-control">
            @error('image')
            <span class="text-danger fs-6">{{ $message }}</span>
            @enderror

            <h5>BMI:</h5>
            <input name="bmi" value="{{ $user->stats->bmi }}" type="number" class="form-control">

            <h5>Squat:</h5>
            <input name="squat" value="{{ $user->stats->squat }}" type="number" class="form-control">

            <h5>Bench Press:</h5>
            <input name="bench_press" value="{{ $user->stats->bench_press }}" type="number" class="form-control">

            <h5>Deadlift:</h5>
            <input name="dead_lift" value="{{ $user->stats->dead_lift }}" type="number" class="form-control">


            <h5>Bio:</h5>
            <textarea name="bio" class="form-control" id="bio" rows="3">{{ $user->bio }}</textarea>
            @error('bio')
            <span class="fs-6 text-danger">{{ $message }}</span>
            @enderror



            <img src="{{ asset('images/post-icon.png') }}" class="post-comment-icon">
            <span id="postCount">{{ $user->posts()->count() }}</span>
            <img src="{{ asset('images/comment-icon.png') }}" class="post-comment-icon">
            <span id="commentCount">{{ $user->comments()->count() }}</span>

        </div>
    </form>
    <form action="{{ route('users.destroy', $user->id) }}" method="POST" class="ms-1">
        @csrf
        @method('DELETE')
        <button type="submit" class="btn btn-danger btn-sm">Delete account</button>
    </form>
</div>



</body>

</html>
