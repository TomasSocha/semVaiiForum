<h4> Share yours posts </h4>
<div class="row">
    <form action="{{route('post.store')}}" method="post">
        @csrf
    <div class="mb-3">
        <textarea name="content" class="form-control" id="content" rows="3"></textarea>
        @error('content')
            <span class="fs-6 text-danger">{{$message}}</span>
        @enderror
    </div>
    <div class="">
        @auth()
        <button type="submit" class="btn btn-dark"> Share </button>
        @endauth
        @guest()
            <h1> Login to share posts!</h1>
            @endguest
    </div>
    </form>
</div>
