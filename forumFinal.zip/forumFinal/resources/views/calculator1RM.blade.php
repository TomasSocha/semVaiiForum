@include('layout.nav-bar')



    <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Powerlifting 1RM Calculator</title>
</head>


<body class="calculator-page-container">


<div style="background-image: url('{{ asset('images/calculator-background.jpg') }}'); background-size: cover; background-position: center; height: 100vh; position: relative;">
    <h1 style="text-align: center; color: #333;"><strong>Powerlifting 1RM Calculator</strong></h1>

    <div class="px-2 pt-4 pb-2 container mt-4">
        <div class="row">

            <div class="col-sm-6">
                <form id="calculatorForm" class="calculator-form">
                    <strong for="exercise">Choose Exercise:</strong>
                    <select id="exercise" name="exercise">
                        <option value="squat">Squat</option>
                        <option value="bench">Bench Press</option>
                        <option value="deadlift">Deadlift</option>
                    </select>
                    <br>
                    <br>

                    <div class="form-group">
                        <strong for="weight">Enter Weight:</strong>
                        <div class="input-group">
                            <input type="number" id="weight" name="weight" required>
                            <select id="unit" name="unit">
                                <option value="kg">kg</option>
                                <option value="lbs">lbs</option>
                            </select>
                        </div>
                    </div>

                    <strong for="reps">Enter Reps:</strong>
                    <br>
                    <input class="input-group" type="number" id="reps" name="reps" required>

                    <br>

                    <button type="button" onclick="calculate1RM()" class="calculator-button"><strong>Calculate 1RM</strong></button>

                    <label for="result" class="calculator-result"><strong>1RM:</strong></label>
                    <span id="result"></span>
                    <br>
                    <br>
                    @auth()
                        <a href="{{ route('users.edit', auth()->user()->id) }}" class="calculator-button">
                            <strong>Update your 1RM here</strong>
                        </a>
                    @endauth
                </form>
            </div>

            <div class="col-sm-6">
                @include('shared.weight-conversion')
            </div>
        </div>
    </div>
</div>
<script src="{{ asset('js/calculator.js') }}"></script>
</body>
</html>


