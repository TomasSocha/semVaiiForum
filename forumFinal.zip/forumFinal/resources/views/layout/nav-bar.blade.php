<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">

<link rel="stylesheet" href="{{ asset('css/style.css') }}">

<nav class="navbar navbar-expand-lg bg-custom-dark">
    <div class="container-fluid">
        <div class="left-buttons">
        <a href="{{ url('/') }}">
             <img src="{{ asset('images/logo.png') }}" class="navbar-brand logo" alt="Company Logo">
        </a>
            <form action="{{ route('forum') }}" method="get">
                <button type="submit" class="forum">Forum</button>
            </form>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav">
                <li class="nav-item">
                    <a class="nav-link active" aria-current="page" href="{{ url('/calculator1RM') }}">1RM-calculator</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link active" aria-current="page" href="{{ url('/calculatorBMI') }}">BMI-calculator</a>
                </li>
                @auth()
                <li class="nav-item">
                    <a href="{{ route('users.show', auth()->user()->id) }}" class="nav-link">Profile</a>
                </li>
                @endauth
            </ul>
        </div>
        </div>
        <div class="button-container">


            @guest()
            <form action="{{ route('login') }}" method="get">
                <button type="submit" class="register">Login</button>
            </form>

            <form action="{{ route('register') }}" method="get">
                <button type="submit" class="register">Register</button>
            </form>
            @endguest

            @auth()
                    <form action="{{ route('logout') }}" method="get">
                        <button type="submit" class="logout">Log out</button>
                    </form>
            @endauth


        </div>
    </div>
</nav>
