@include('layout.nav-bar')

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title> User Registration</title>
</head>
<body class="registration-page">

<div class="registration-background" style="background-image: url('{{ asset('images/registration-background.jpg') }}'); background-size: cover; background-position: center; height: 100vh; position: relative;">


<form action="{{ route('register') }}" method="post" class="registration-form">
    @csrf

    <h2 class="title">User Registration</h2>

    <label for="reg-username">Username:</label>
    <input type="text" id="name" name="name" required>

    @error('name')
    <span class="d-block fs-6 text-danger mt-2"> {{ $message }} </span>
    @enderror

    <label for="reg-email">Email:</label>
    <input type="email" id="email" name="email" required>

    @error('email')
    <span class="d-block fs-6 text-danger mt-2"> {{ $message }} </span>
    @enderror

    <label for="reg-password">Password:</label>
    <input type="password" id="password" name="password" required>

    @error('password')
    <span class="d-block fs-6 text-danger mt-2"> {{ $message }} </span>
    @enderror

    <label for="reg-password_confirmation">Confirm Password:</label>
    <input type="password" id="password_confirmation" name="password_confirmation" required>

    @error('password_confirmation')
    <span class="d-block fs-6 text-danger mt-2"> {{ $message }} </span>
    @enderror

    <button type="submit" class="register-btn">Register</button>

    <a href="/login" class="login-link">Login here</a>
</form>
</div>
</body>


