@include('layout.nav-bar')

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Registration</title>
</head>
<body class="registration-page">

<div class="registration-background" style="background-image: url('{{ asset('images/registration-background.jpg') }}'); background-size: cover; background-position: center; height: 100vh; position: relative;">


<form action="{{ route('login') }}" method="post" class="registration-form">
    @csrf

    <h2 class="title">User Login</h2>

    <label for="reg-email">Email:</label>
    <input type="email" id="email" name="email" required>

    @error('email')
    <span class="d-block fs-6 text-danger mt-2"> {{ $message }} </span>
    @enderror

    <label for="reg-password">Password:</label>
    <input type="password" id="password" name="password" required>

    @error('password')
    <span class="d-block fs-6 text-danger mt-2"> {{ $message }} </span>
    @enderror

    <button type="submit" class="login-btn">Login</button>

    <a href="/register" class="login-link">Register here</a>
</form>
</div>
</body>

