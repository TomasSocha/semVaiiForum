@include('layout.nav-bar')

    <!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Profile</title>
</head>

<body class="profile-page">

<div class="profile-container">
    <img src={{$user->getImage()}}  class="profile-image">
    <div class="profile-info">
        @can('update', $user)
            <a href="{{ route('users.edit', $user->id) }}" class="ms-1 crud-button">
                <img src="{{ asset('images/edit-icon.png') }}" class="edit-profile-icon">
            </a>
        @endcan
        <h2>{{$user->name}}</h2>
                @if ($user->stats->bmi != null)
                    <span style="display: inline-block; margin-right: 10px;">BMI: {{ $user->stats->bmi }}</span>
                @endif
                @if ($user->stats->squat != null)
                    <span style="display: inline-block; margin-right: 10px;">Squat: {{ $user->stats->squat}}</span>
                @endif
                @if ($user->stats->bench_press != null)
                    <span style="display: inline-block; margin-right: 10px;">Bench Press: {{ $user->stats->bench_press }}</span>
                @endif
                @if ($user->stats->dead_lift != null)
                    <span style="display: inline-block; margin-right: 10px;">Deadlift: {{ $user->stats->dead_lift }}</span>
                @endif
                @if ($user->bio != null)
                    <p>{{ $user->bio }}</p>
                @endif

        <p></p>
        <img src="{{ asset('images/post-icon.png') }}" class="post-comment-icon">

        <span id="postCount">{{$user->posts()->count()}}</span>
        <img src="{{ asset('images/comment-icon.png') }}" class="post-comment-icon">
        <span id="commentCount">{{$user->comments()->count()}}</span>

    </div>

        @foreach($posts as $post)
            <div class="mt-3">
                @include('shared.post-card',['post' => $post])
            </div>
        @endforeach
        {{$posts->withQueryString()->links()}}
</div>

</body>

</html>
