function calculate1RM() {
    const exercise = document.getElementById("exercise").value;
    const weight = parseFloat(document.getElementById("weight").value);
    const unit = document.getElementById("unit").value;
    const reps = parseInt(document.getElementById("reps").value);

    if (isNaN(weight) || weight <= 0 || isNaN(reps) || reps <= 0) {
        alert("Please enter valid weight and reps.");
        return;
    }

    let oneRM;

    if (unit === "kg" || unit === "lbs") {
        oneRM = weight * (1 + 0.0333 * reps);
    } else {
        alert("Please choose a valid unit.");
        return;
    }

    document.getElementById("result").innerText = ` ${exercise} - ${oneRM.toFixed(2)} ${unit}`;
}

function calculateConversionWeight() {
    var conversionWeight = parseFloat(document.getElementById('conversionWeight').value);
    var conversionUnit = document.getElementById('conversionUnit').value;

    const KG_TO_LBS = 2.20462;
    const LBS_TO_KG = 0.453592;

    var result;
    if (conversionUnit === 'kg') {
        result = conversionWeight * KG_TO_LBS;
        document.getElementById('conversionResult').innerText = result.toFixed(2) + ' lbs';
    } else if (conversionUnit === 'lbs') {
        result = conversionWeight * LBS_TO_KG;
        document.getElementById('conversionResult').innerText = result.toFixed(2) + ' kg';
    } else {
        alert('Invalid unit selected.');
    }
}

function calculateConversionLength() {

    var conversionWeight = parseFloat(document.getElementById('conversionLength').value);
    var conversionUnit = document.getElementById('conversionUnitLength').value;


    const CM_TO_INCHES = 0.393701;
    const INCHES_TO_CM = 2.54;


    var result;
    if (conversionUnit === 'cm') {
        result = conversionWeight * CM_TO_INCHES;
        document.getElementById('conversionResultLength').innerText = result.toFixed(2) + ' inches';
    } else if (conversionUnit === 'inches') {
        result = conversionWeight * INCHES_TO_CM;
        document.getElementById('conversionResultLength').innerText = result.toFixed(2) + ' cm';
    } else {

        alert('Invalid unit selected.');
    }
}

function calculateBMI() {
    var metrics = document.getElementById('metrics').value;
    var weight = parseFloat(document.getElementById('weight').value);
    var height = parseFloat(document.getElementById('height').value);


    if (isNaN(weight) || isNaN(height) || weight <= 0 || height <= 0) {
        alert('Please enter valid weight and height.');
        return;
    }


    if (metrics === 'imperial') {
        weight = weight * 0.453592;
        height = height * 2.54;
    }


    var bmi = weight / Math.pow(height / 100, 2);


    document.getElementById('bmiResult').textContent = bmi.toFixed(2);
}
