$(document).ready(function () {
    function updateCreationTime(postId) {
        $.ajax({
            type: 'GET',
            url: '/post/creation-time/' + postId,
            success: function (response) {
                var secondsAgo = response.secondsAgo;

                var timeDisplay;
                if (secondsAgo < 60) {
                    timeDisplay = secondsAgo + ' seconds ago';
                } else if (secondsAgo < 3600) {
                    var minutes = Math.floor(secondsAgo / 60);
                    timeDisplay = minutes + ' minute' + (minutes !== 1 ? 's' : '') + ' ago';
                } else if (secondsAgo < 86400) {
                    var hours = Math.floor(secondsAgo / 3600);
                    timeDisplay = hours + ' hour' + (hours !== 1 ? 's' : '') + ' ago';
                } else if (secondsAgo < 2592000) {
                    var days = Math.floor(secondsAgo / 86400);
                    timeDisplay = days + ' day' + (days !== 1 ? 's' : '') + ' ago';
                } else if (secondsAgo < 31536000) {
                    var months = Math.floor(secondsAgo / 2592000);
                    timeDisplay = months + ' month' + (months !== 1 ? 's' : '') + ' ago';
                } else {
                    var years = Math.floor(secondsAgo / 31536000);
                    timeDisplay = years + ' year' + (years !== 1 ? 's' : '') + ' ago';
                }

                $('.creation-time[data-post-id="' + postId + '"]').text(timeDisplay);
            },
            error: function (error) {
                console.error('Error fetching creation time:', error);
            }
        });
    }


    $('[data-post-id]').each(function () {
        var postId = $(this).data('post-id');
        updateCreationTime(postId);
    });


    setInterval(function () {
        $('[data-post-id]').each(function () {
            var postId = $(this).data('post-id');
            updateCreationTime(postId);
        });
    }, 600000); //kazdych 60 sekund
});
