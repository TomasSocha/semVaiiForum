<div class="post-frame">
    <div class="custom-card">
        <div class="custom-header px-3 pt-4 pb-2">
            <div class="d-flex align-items-center justify-content-between">
                <div class="d-flex align-items-center">
                    <img style="width: 45px; height: 45px" class="me-2 avatar-sm rounded-circle" src="<?php echo e($post->user->getImage()); ?>">
                    <div>
                        <h5 class="custom-title mb-0">
                            <a class="user-link" href="<?php echo e(route('users.show', $post->user->id)); ?>"><?php echo e($post->user->name); ?></a>
                        </h5>
                    </div>
                </div>

                <div>
                    <form method="POST" action="<?php echo e(route('post.destroy', $post->id)); ?>">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('delete'); ?>
                        <a href="<?php echo e(route('post.show', $post->id)); ?>" class="crud-button">
                            <img src="<?php echo e(asset('images/view-icon.png')); ?>" class="view-icon">
                        </a>
                        <?php if(auth()->guard()->check()): ?>
                            <?php if(auth()->user()->id === $post->user_id): ?>
                                <a href="<?php echo e(route('post.edit', $post->id)); ?>" class="ms-1 crud-button">
                                    <img src="<?php echo e(asset('images/edit-icon.png')); ?>" class="edit-icon">
                                </a>
                                <form action="<?php echo e(route('post.destroy', $post->id)); ?>" method="POST" class="ms-1">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-danger btn-sm">Delete</button>
                                </form>
                            <?php endif; ?>
                        <?php endif; ?>
                    </form>
                </div>
            </div>
        </div>

        <div class="custom-body card-body">
            <?php if($editing ?? false): ?>
                <form action="<?php echo e(route('post.update', $post->id)); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <div class="mb-3">
                        <textarea name="content" class="form-control" id="content" rows="3"><?php echo e($post->content); ?></textarea>
                        <?php $__errorArgs = ['content'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="fs-6 text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="">
                        <button type="submit" class="btn btn-dark">Share</button>
                    </div>
                </form>
            <?php else: ?>
                <p class="fs-6 fw-light text-muted"><?php echo e($post->content); ?></p>
            <?php endif; ?>

                <div class="d-flex justify-content-between">
                    <div>
        <span class="fs-6 fw-light text-muted creation-time" data-post-id="<?php echo e($post->id); ?>">
            <span class="fas fa-clock"></span>
            <?php echo e($post->created_at); ?>

        </span>
                    </div>
                </div>


                <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
                <script src="<?php echo e(asset('js/time-updater.js')); ?>"></script>


                <?php echo $__env->make('shared.comments-card', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>
</div>
<?php /**PATH C:\Users\tomas\OneDrive\Počítač\FinalSemestranaPraca\forumFinal\resources\views/shared/post-card.blade.php ENDPATH**/ ?>