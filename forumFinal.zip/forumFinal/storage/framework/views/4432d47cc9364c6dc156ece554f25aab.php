<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">

<link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">

<nav class="navbar navbar-expand-lg bg-custom-dark">
    <div class="container-fluid">
        <div class="left-buttons">
        <a href="<?php echo e(url('/')); ?>">
             <img src="<?php echo e(asset('images/logo.png')); ?>" class="navbar-brand logo" alt="Company Logo">
        </a>
            <form action="<?php echo e(route('forum')); ?>" method="get">
                <button type="submit" class="forum">Forum</button>
            </form>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav">
                <li class="nav-item">
                    <a class="nav-link active" aria-current="page" href="<?php echo e(url('/calculator1RM')); ?>">1RM-calculator</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link active" aria-current="page" href="<?php echo e(url('/calculatorBMI')); ?>">BMI-calculator</a>
                </li>
                <?php if(auth()->guard()->check()): ?>
                <li class="nav-item">
                    <a href="<?php echo e(route('users.show', auth()->user()->id)); ?>" class="nav-link">Profile</a>
                </li>
                <?php endif; ?>
            </ul>
        </div>
        </div>
        <div class="button-container">


            <?php if(auth()->guard()->guest()): ?>
            <form action="<?php echo e(route('login')); ?>" method="get">
                <button type="submit" class="register">Login</button>
            </form>

            <form action="<?php echo e(route('register')); ?>" method="get">
                <button type="submit" class="register">Register</button>
            </form>
            <?php endif; ?>

            <?php if(auth()->guard()->check()): ?>
                    <form action="<?php echo e(route('logout')); ?>" method="get">
                        <button type="submit" class="logout">Log out</button>
                    </form>
            <?php endif; ?>


        </div>
    </div>
</nav>
<?php /**PATH C:\Users\tomas\OneDrive\Počítač\FinalSemestranaPraca\forumFinal\resources\views/layout/nav-bar.blade.php ENDPATH**/ ?>