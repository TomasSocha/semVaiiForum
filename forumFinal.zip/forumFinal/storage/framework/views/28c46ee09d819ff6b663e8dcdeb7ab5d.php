<?php echo $__env->make('layout.nav-bar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Profile</title>
</head>

<body class="profile-page">

<div class="profile-container">
    <img src=<?php echo e($user->getImage()); ?>  class="profile-image">
    <div class="profile-info">
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update', $user)): ?>
            <a href="<?php echo e(route('users.edit', $user->id)); ?>" class="ms-1 crud-button">
                <img src="<?php echo e(asset('images/edit-icon.png')); ?>" class="edit-profile-icon">
            </a>
        <?php endif; ?>
        <h2><?php echo e($user->name); ?></h2>
                <?php if($user->stats->bmi != null): ?>
                    <span style="display: inline-block; margin-right: 10px;">BMI: <?php echo e($user->stats->bmi); ?></span>
                <?php endif; ?>
                <?php if($user->stats->squat != null): ?>
                    <span style="display: inline-block; margin-right: 10px;">Squat: <?php echo e($user->stats->squat); ?></span>
                <?php endif; ?>
                <?php if($user->stats->bench_press != null): ?>
                    <span style="display: inline-block; margin-right: 10px;">Bench Press: <?php echo e($user->stats->bench_press); ?></span>
                <?php endif; ?>
                <?php if($user->stats->dead_lift != null): ?>
                    <span style="display: inline-block; margin-right: 10px;">Deadlift: <?php echo e($user->stats->dead_lift); ?></span>
                <?php endif; ?>
                <?php if($user->bio != null): ?>
                    <p><?php echo e($user->bio); ?></p>
                <?php endif; ?>

        <p></p>
        <img src="<?php echo e(asset('images/post-icon.png')); ?>" class="post-comment-icon">

        <span id="postCount"><?php echo e($user->posts()->count()); ?></span>
        <img src="<?php echo e(asset('images/comment-icon.png')); ?>" class="post-comment-icon">
        <span id="commentCount"><?php echo e($user->comments()->count()); ?></span>

    </div>

        <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="mt-3">
                <?php echo $__env->make('shared.post-card',['post' => $post], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php echo e($posts->withQueryString()->links()); ?>

</div>

</body>

</html>
<?php /**PATH C:\Users\tomas\OneDrive\Počítač\FinalSemestranaPraca\forumFinal\resources\views/profile-page.blade.php ENDPATH**/ ?>