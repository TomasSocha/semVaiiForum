<form id="conversionForm" class="calculator-form">
    <strong for="conversionWeight" class="control-label">Enter Weight:</strong>
    <div class="input-group">
        <input type="number" id="conversionWeight" name="conversionWeight" required>
        <select id="conversionUnit" name="conversionUnit">
            <option value="kg">kg</option>
            <option value="lbs">lbs</option>
        </select>
    </div>

    <button type="button" onclick="calculateConversionWeight()" class="calculator-button">Calculate Weight Conversion</button>

    <label for="conversionResult" class="calculator-result">Converted Weight:</label>
    <span id="conversionResult"></span>
</form>
<?php /**PATH C:\Users\tomas\OneDrive\Počítač\FinalSemestranaPraca\forumFinal\resources\views/shared/weight-conversion.blade.php ENDPATH**/ ?>