<?php echo $__env->make('layout.nav-bar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Registration</title>
</head>
<body class="registration-page">

<div class="registration-background" style="background-image: url('<?php echo e(asset('images/registration-background.jpg')); ?>'); background-size: cover; background-position: center; height: 100vh; position: relative;">


<form action="<?php echo e(route('login')); ?>" method="post" class="registration-form">
    <?php echo csrf_field(); ?>

    <h2 class="title">User Login</h2>

    <label for="reg-email">Email:</label>
    <input type="email" id="email" name="email" required>

    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <span class="d-block fs-6 text-danger mt-2"> <?php echo e($message); ?> </span>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

    <label for="reg-password">Password:</label>
    <input type="password" id="password" name="password" required>

    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <span class="d-block fs-6 text-danger mt-2"> <?php echo e($message); ?> </span>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

    <button type="submit" class="login-btn">Login</button>

    <a href="/register" class="login-link">Register here</a>
</form>
</div>
</body>

<?php /**PATH C:\Users\tomas\OneDrive\Počítač\FinalSemestranaPraca\forumFinal\resources\views/auth/login-card.blade.php ENDPATH**/ ?>