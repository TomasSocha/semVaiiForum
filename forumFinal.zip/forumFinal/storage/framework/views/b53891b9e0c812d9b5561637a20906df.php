<div class="col-3">
    <div class="search-bar-frame">
        <div class="card-header pb-0 border-0">
            <h5 class="">Search</h5>
        </div>
        <div class="card-body">
            <form action="<?php echo e(route('forum')); ?>" method="GET">
                <input value="<?php echo e(request('search', '')); ?>" name="search" placeholder="" class="form-control w-100" type="text">
                <label class="mt-2">Search in Usernames
                    <input type="checkbox" name="search_users" value="1" <?php echo e(request('search_users') ? 'checked' : ''); ?>>
                </label>
                <button class="btn btn-dark mt-2">Search</button>
            </form>
        </div>
    </div>
</div>
<?php /**PATH C:\Users\tomas\OneDrive\Počítač\FinalSemestranaPraca\forumFinal\resources\views/shared/search.blade.php ENDPATH**/ ?>