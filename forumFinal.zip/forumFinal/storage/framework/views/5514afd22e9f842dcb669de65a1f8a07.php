<div>
    <form  id="commentForm"  action="<?php echo e(route('post.comments.store',$post->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
    <div class="mb-3">
        <textarea id="content" name="content" class="fs-6 form-control" rows="1"></textarea>
    </div>
    <div>
        <button type="submit" class="btn btn-dark btn-sm"> Post Comment </button>
    </div>
    </form>
    <hr>

    <?php $__currentLoopData = $post->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="d-flex align-items-start comment-container">
            <?php if(Auth::id() === $comment->user->id): ?>
                <form method="POST" action="<?php echo e(route('post.comments.delete', ['post' => $post->id, 'comment' => $comment->id])); ?>">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="btn btn-sm">Delete</button>
                </form>
            <?php endif; ?>

            <img style="width: 35px; height: 35px" class="me-2 avatar-sm rounded-circle"
                 src="<?php echo e($comment->user->getImage()); ?>">
            <div class="w-100">
                <div class="d-flex justify-content-between">
                    <h6 class=""><a class="user-link" href="<?php echo e(route('users.show',$comment->user->id)); ?>"><?php echo e($comment->user->name); ?></a></h6>



                    <small class="fs-6 fw-light text-muted"><?php echo e($comment->created_at); ?></small>

                </div>

                <p class="fs-6 fw-light">
                    <?php echo e($comment->content); ?>

                </p>

            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <script src="<?php echo e(asset('js/comment.js')); ?>"></script>
</div>
<?php /**PATH C:\Users\tomas\OneDrive\Počítač\FinalSemestranaPraca\forumFinal\resources\views/shared/comments-card.blade.php ENDPATH**/ ?>