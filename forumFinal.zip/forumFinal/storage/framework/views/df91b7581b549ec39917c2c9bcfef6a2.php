<h4> Share yours posts </h4>
<div class="row">
    <form action="<?php echo e(route('post.store')); ?>" method="post">
        <?php echo csrf_field(); ?>
    <div class="mb-3">
        <textarea name="content" class="form-control" id="content" rows="3"></textarea>
        <?php $__errorArgs = ['content'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="fs-6 text-danger"><?php echo e($message); ?></span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <div class="">
        <?php if(auth()->guard()->check()): ?>
        <button type="submit" class="btn btn-dark"> Share </button>
        <?php endif; ?>
        <?php if(auth()->guard()->guest()): ?>
            <h1> Login to share posts!</h1>
            <?php endif; ?>
    </div>
    </form>
</div>
<?php /**PATH C:\Users\tomas\OneDrive\Počítač\FinalSemestranaPraca\forumFinal\resources\views/shared/create-post.blade.php ENDPATH**/ ?>