<form id="lengthConversionForm" class="calculator-form">
    <strong for="conversionLength" class="control-label">Enter Length:</strong>
    <div class="input-group">
        <input type="number" id="conversionLength" name="conversionLength" required>
        <select id="conversionUnitLength" name="conversionUnitLength">
            <option value="cm">cm</option>
            <option value="inches">inches</option>
        </select>
    </div>

    <button type="button" onclick="calculateConversionLength()" class="calculator-button">Calculate Length Conversion</button>

    <label for="conversionResultLength" class="calculator-result">Converted Length:</label>
    <span id="conversionResultLength"></span>
</form>
<?php /**PATH C:\Users\tomas\OneDrive\Počítač\FinalSemestranaPraca\forumFinal\resources\views/shared/length-conversion.blade.php ENDPATH**/ ?>