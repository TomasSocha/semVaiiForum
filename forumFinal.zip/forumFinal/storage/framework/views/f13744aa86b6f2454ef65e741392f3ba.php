<?php echo $__env->make('layout.nav-bar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<div id="carouselExampleDark" class="carousel carousel-light slide">
    <div class="carousel-indicators">
        <button type="button" data-bs-target="#carouselExampleDark" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
        <button type="button" data-bs-target="#carouselExampleDark" data-bs-slide-to="1" aria-label="Slide 2"></button>
        <button type="button" data-bs-target="#carouselExampleDark" data-bs-slide-to="2" aria-label="Slide 3"></button>
    </div>
    <div class="carousel-inner">
        <div class="carousel-item active" data-bs-interval="10000">
            <img src="<?php echo e(asset('images/registration-background.jpg')); ?>" class="d-block w-100" alt="...">
            <div class="carousel-caption d-none d-md-block" >
                <h5 class="carousel-title" >Forum</h5>
                <p class="carousel-text">This section is dedicated to discussions related to fitness, workouts, and gym experiences. Users can engage in conversations, ask questions, and share their knowledge with the community.</p>
            </div>
        </div>
        <div class="carousel-item" data-bs-interval="2000">
            <img src="<?php echo e(asset('images/powerlifting.jpg')); ?>" class="d-block w-100" alt="...">
            <div class="carousel-caption d-none d-md-block">
                <h5 class="carousel-title">1RM Calculator</h5>
                <p class="carousel-text">The 1RM (One Rep Max) Calculator helps users estimate their maximum lifting capacity for a given exercise. Users input the weight lifted and the number of reps performed, and the calculator provides an estimated 1RM value.</p>
            </div>
        </div>
        <div class="carousel-item">
            <img src="<?php echo e(asset('images/food.webp')); ?>" class="d-block w-100" alt="...">
            <div class="carousel-caption d-none d-md-block">
                <h5 class="carousel-title">BMI Calculator</h5>
                <p class="carousel-text">>The BMI (Body Mass Index) Calculator helps users assess their body mass based on their height and weight. Users input their height in inches and weight in pounds, and the calculator provides a BMI value along with an interpretation of the result.

                </p>
            </div>
        </div>
    </div>
    <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleDark" data-bs-slide="prev">
        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
        <span class="visually-hidden">Previous</span>
    </button>
    <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleDark" data-bs-slide="next">
        <span class="carousel-control-next-icon" aria-hidden="true"></span>
        <span class="visually-hidden">Next</span>
    </button>
</div>
<?php /**PATH C:\Users\tomas\OneDrive\Počítač\FinalSemestranaPraca\forumFinal\resources\views/home.blade.php ENDPATH**/ ?>