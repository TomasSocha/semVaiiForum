<?php echo $__env->make('layout.nav-bar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<!-- calculator1RM.blade.php -->

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Powerlifting 1RM Calculator</title>
</head>
<body class="calculator-page-container">

<h1 style="text-align: center; color: #333;">Powerlifting 1RM Calculator</h1>

<div class="px-2 pt-4 pb-2 container mt-4">
    <div class="row">
        <!-- Calculator Tab -->
        <div class="col-sm-6">
            <form id="calculatorForm" class="calculator-form">
                <label for="exercise">Choose Exercise:</label>
                <select id="exercise" name="exercise">
                    <option value="squat">Squat</option>
                    <option value="bench">Bench Press</option>
                    <option value="deadlift">Deadlift</option>
                </select>
                <br>
                <br>

                <div class="form-group">
                    <label for="weight" class="control-label">Enter Weight:</label>
                    <div class="input-group">
                        <input type="number" id="weight" name="weight" required>
                        <select id="unit" name="unit">
                            <option value="kg">kg</option>
                            <option value="lbs">lbs</option>
                        </select>
                    </div>
                </div>

                <label for="reps">Enter Reps:</label>
                <br>
                <input class="input-group" type="number" id="reps" name="reps" required>

                <br>

                <button type="button" onclick="calculate1RM()" class="calculator-button">Calculate 1RM</button>

                <label for="result" class="calculator-result">1RM:</label>
                <span id="result"></span>
            </form>
        </div>


        <div class="col-sm-6">
            <?php echo $__env->make('shared.weight-conversion', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>

    </div>
</div>

<script src="<?php echo e(asset('js/calculator.js')); ?>"></script>
</body>
</html>


<?php /**PATH C:\Users\tomas\OneDrive\Počítač\FinalSemestranaPraca\forumFinal\resources\views/calculator1RM.blade.php ENDPATH**/ ?>
