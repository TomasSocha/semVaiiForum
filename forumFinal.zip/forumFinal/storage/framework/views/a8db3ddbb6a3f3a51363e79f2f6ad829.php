<?php echo $__env->make('layout.nav-bar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Profile</title>
</head>

<body class="profile-page">

<div class="profile-container">
    <img src=<?php echo e($user->getImage()); ?> class="profile-image">
    <form enctype="multipart/form-data" method="POST" action="<?php echo e(route('users.update', $user->id)); ?>">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <div class="profile-info">

            <button type="submit" class="ms-1 crud-button">
                <img src="<?php echo e(asset('images/save-icon.png')); ?>" class="edit-profile-icon" alt="Save">
            </button>
            <h5>Name:</h5>
            <input name="name" value="<?php echo e($user->name); ?>" type="text" class="form-control">
            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="text-danger fs-6"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            <h5>Profile picture:</h5>
            <input name="image" type="file" class="form-control">
            <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="text-danger fs-6"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            <h5>BMI:</h5>
            <input name="bmi" value="<?php echo e($user->stats->bmi); ?>" type="number" class="form-control">

            <h5>Squat:</h5>
            <input name="squat" value="<?php echo e($user->stats->squat); ?>" type="number" class="form-control">

            <h5>Bench Press:</h5>
            <input name="bench_press" value="<?php echo e($user->stats->bench_press); ?>" type="number" class="form-control">

            <h5>Deadlift:</h5>
            <input name="dead_lift" value="<?php echo e($user->stats->dead_lift); ?>" type="number" class="form-control">


            <h5>Bio:</h5>
            <textarea name="bio" class="form-control" id="bio" rows="3"><?php echo e($user->bio); ?></textarea>
            <?php $__errorArgs = ['bio'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="fs-6 text-danger"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>



            <img src="<?php echo e(asset('images/post-icon.png')); ?>" class="post-comment-icon">
            <span id="postCount"><?php echo e($user->posts()->count()); ?></span>
            <img src="<?php echo e(asset('images/comment-icon.png')); ?>" class="post-comment-icon">
            <span id="commentCount"><?php echo e($user->comments()->count()); ?></span>

        </div>
    </form>
    <form action="<?php echo e(route('users.destroy', $user->id)); ?>" method="POST" class="ms-1">
        <?php echo csrf_field(); ?>
        <?php echo method_field('DELETE'); ?>
        <button type="submit" class="btn btn-danger btn-sm">Delete account</button>
    </form>
</div>



</body>

</html>
<?php /**PATH C:\Users\tomas\OneDrive\Počítač\FinalSemestranaPraca\forumFinal\resources\views/shared/edit-profile-page.blade.php ENDPATH**/ ?>